from django.shortcuts import render
from movie1.models import movie
from movie1.forms import movieform


# Create your views here.
def home(request):
    img = movie.objects.all()
    return render(request, 'home.html', {"img": img})


def view(request, pk):
    s = movie.objects.get(id=pk)
    return render(request, 'view.html', {"s": s})


def update(request, p):
    b = movie.objects.get(id=p)
    f = movieform(instance=b)
    if (request.method == "POST"):
        print(request.POST)
        f = movieform(request.POST, instance=b)
        if (f.is_valid()):
            f.save()
        return home(request)

    return render(request, 'update.html', {'form': f})


def delete(request, p):
    b = movie.objects.get(id=p)
    b.delete()
    return home(request)

def add(request):
        f = movieform()  # Creates Empty form object
        if (request.method == "POST"):
            print(request.POST)
            f = movieform(request.POST, request.FILES)
            if (f.is_valid()):
                f.save()
                return home(request)
        return render(request, 'add.html', {'form': f})
