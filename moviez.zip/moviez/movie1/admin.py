from django.contrib import admin
from movie1.models import movie
# Register your models here.
admin.site.register(movie)